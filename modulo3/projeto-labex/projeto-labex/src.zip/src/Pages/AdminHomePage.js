import React, {useState, useEffect} from "react";




function AdminHomePage() {
  return (
    <div>
        ADMIN HOME PAGE
    </div>
    
  );
}

export default AdminHomePage;