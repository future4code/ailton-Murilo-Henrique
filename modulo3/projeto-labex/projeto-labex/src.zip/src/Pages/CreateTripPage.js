import React, {useState, useEffect} from "react";




function CreateTripPage() {
  return (
    <div>
        CREATE TRIP PAGE
    </div>
    
  );
}

export default CreateTripPage;