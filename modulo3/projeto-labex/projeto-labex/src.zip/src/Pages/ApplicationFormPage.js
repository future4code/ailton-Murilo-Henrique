import React, {useState, useEffect} from "react";




function ApplicationFormPage() {
  return (
    <div>
        APP FORM PAGE
    </div>
    
  );
}

export default ApplicationFormPage;