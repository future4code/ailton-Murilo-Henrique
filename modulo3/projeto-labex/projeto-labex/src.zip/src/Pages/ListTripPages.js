import React, {useState, useEffect} from "react";




function ListTripPages() {
  return (
    <div>
        LIST TRIP PAGES
    </div>
    
  );
}

export default ListTripPages;