import React, {useState, useEffect} from "react";




function TripDetailsPage() {
  return (
    <div>
       TRIP DETAILS PAGE
    </div>
    
  );
}

export default TripDetailsPage;