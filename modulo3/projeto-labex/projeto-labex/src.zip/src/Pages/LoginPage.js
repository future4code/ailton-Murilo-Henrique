import React, {useState, useEffect} from "react";




function LoginPage() {
  return (
    <div>
        LOGIN PAGE
    </div>
    
  );
}

export default LoginPage;